<#
    .SYNOPSIS
    <A brief description of the script>
    .DESCRIPTION
    <A detailed description of the script>
    .PARAMETER <paramName>
    <Description of script parameter>
    .EXAMPLE
    <An example of using the script>
#>

$fire = Get-Package -Name mozilla*
foreach($fox in $fire)
{
  if($fox.version -lt 58)
  {
    Write-Host 'Update Needed for'$fox.Name': ' -NoNewline
    Write-Host 'Yes' -ForegroundColor red
  }
  if($fox.version -gt 58)
  {
    Write-Host 'Version'$fox.version'rnning. Update Needed for'$fox.Name': ' -NoNewline
    Write-Host 'No' -ForegroundColor green
  }
}
        
        
Get-ChildItem -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall |
ForEach-Object -Process {
  Get-ItemProperty -Path $_.PsPath
} |
Where-Object -FilterScript {
  $_.Displayname -and ($_.Displayname -match '.*')
} |
Sort-Object -Property Displayname |
Select-Object -Property DisplayName, Publisher

